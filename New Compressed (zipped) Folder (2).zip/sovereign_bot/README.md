
# Sovereign Trading Bot

Sovereign is a bi-directional (Long/Short) Autonomous Trading Bot designed for cloud deployment. It uses a multi-LLM consensus mechanism for decision-making and provides headless control via Telegram.

## Features

- **Persistent Vault**: All trades are logged in a SQLite database.
- **2026 NTA Tax Engine**: Calculates Nigerian capital gains tax for 2026.
- **Multi-LLM Consensus**: Uses Groq for news analysis and OpenRouter (Gemini 2.0 Flash) for final trade confirmation.
- **Market Scanning**: Scans Binance Futures using multi-timeframe analysis and orderbook imbalance checks.
- **Risk Management**: Implements Kelly Criterion for position sizing, ATR for dynamic stop-losses, and a global kill-switch.
- **Telegram Control**: Full control via a whitelisted Telegram ID.
- **Health Monitoring**: A Flask heartbeat for uptime monitoring services like UptimeRobot.

## Setup & Configuration

### 1. Environment Variables

The bot is configured using environment variables. Create a `.env` file in the root of the `sovereign_bot` directory. You can use `.env.example` as a template.

```bash
# sovereign_bot/.env
TELEGRAM_BOT_TOKEN="YOUR_TELEGRAM_BOT_TOKEN"
WHITELISTED_TELEGRAM_ID="YOUR_TELEGRAM_ID"
CRYPTOPANIC_API_KEY="YOUR_CRYPTOPANIC_API_KEY"
GROQ_API_KEY="YOUR_GROQ_API_KEY"
OPENROUTER_API_KEY="YOUR_OPENROUTER_API_KEY"
BINANCE_API_KEY="YOUR_BINANCE_API_KEY"
BINANCE_SECRET_KEY="YOUR_BINANCE_SECRET_KEY"
```

### 2. Required API Keys

- **Telegram**: Get your Bot Token from `@BotFather` and your User ID from `@userinfobot`.
- **CryptoPanic**: [https://cryptopanic.com/developers/api/](https://cryptopanic.com/developers/api/)
- **Groq**: [https://console.groq.com/keys](https://console.groq.com/keys)
- **OpenRouter**: [https://openrouter.ai/keys](https://openrouter.ai/keys)
- **Binance**: Generate API keys with Futures trading enabled.

## Deployment with Docker

The project is designed to be run inside a Docker container.

### 1. Build the Docker Image

Navigate to the `sovereign_bot` directory (where the `Dockerfile` is) and run:

```bash
docker build -t sovereign-bot .
```

### 2. Run the Docker Container

Run the container, passing in your `.env` file.

```bash
docker run -d --name sovereign-bot-container --env-file ./.env -p 8080:8080 sovereign-bot
```

This command will:
- `-d`: Run the container in detached mode.
- `--name sovereign-bot-container`: Give the container a name.
- `--env-file ./.env`: Load your environment variables from the `.env` file.
- `-p 8080:8080`: Map port 8080 on your host to port 8080 in the container for the heartbeat.

To view the bot's logs:
```bash
docker logs -f sovereign-bot-container
```

## Telegram Commands

- `/start`: Activates the bot and confirms it's running.
- `/help`: Shows the list of available commands.
- `/status`: Displays current equity and lists all open positions.
- `/tax`: Provides a full tax report based on the 2026 NTA rules for all realized profits.
- `/reserve`: Shows the total amount of profit that has been logged to the virtual withdrawal reserve.
- `/kill`: Engages the emergency kill-switch, which immediately attempts to close all open positions.
