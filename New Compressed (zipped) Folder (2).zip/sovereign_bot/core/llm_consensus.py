
import requests
import groq
from openai import OpenAI
from ..config import config

# --- CryptoPanic News Fetching ---
def get_crypto_panic_news():
    """Fetches the latest news from the CryptoPanic API."""
    url = f"https://cryptopanic.com/api/v1/posts/?auth_token={config.CRYPTOPANIC_API_KEY}&public=true"
    try:
        response = requests.get(url)
        response.raise_for_status()
        news = response.json().get('results', [])
        # We only need the titles for quick sentiment analysis
        return [n['title'] for n in news[:10]] # Get top 10 recent news titles
    except requests.exceptions.RequestException as e:
        print(f"Error fetching news from CryptoPanic: {e}")
        return []

# --- Groq Integration for News Filtering ---
def filter_news_with_groq(news_titles):
    """
    Analyzes a list of news titles using Groq's Llama3-70b for overall market sentiment.
    """
    if not news_titles:
        return "NEUTRAL"
        
    try:
        client = groq.Groq(api_key=config.GROQ_API_KEY)
        
        system_prompt = (
            "You are a crypto market sentiment analyst. Your task is to analyze a list of news headlines "
            "and determine the overall market sentiment. Respond with a single word: "
            "BULLISH, BEARISH, or NEUTRAL."
        )
        
        user_prompt = "Analyze these headlines:\n\n" + "\n".join(f"- {title}" for title in news_titles)
        
        chat_completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            model="llama3-70b-8192",
            temperature=0.1,
            max_tokens=10,
        )
        
        sentiment = chat_completion.choices[0].message.content.strip().upper()
        if sentiment in ["BULLISH", "BEARISH", "NEUTRAL"]:
            return sentiment
        return "NEUTRAL" # Default if the response is unexpected
    except Exception as e:
        print(f"Error with Groq API: {e}")
        return "NEUTRAL" # Fail-safe

# --- OpenRouter Integration for Final Confirmation ---
def get_final_confirmation(market_data, news_sentiment):
    """
    Uses OpenRouter with a powerful model for a final trade decision.
    """
    try:
        client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=config.OPENROUTER_API_KEY,
        )
        
        system_prompt = (
            "You are a sophisticated trading algorithm's final decision-making core. "
            "You will be given structured market data and a general news sentiment. "
            "Your job is to synthesize this information and provide a single, definitive trading action. "
            "Your possible responses are: LONG, SHORT, or HOLD."
        )

        user_prompt = (
            "Analyze the following data and decide on a trading action.\n\n"
            "## General Market Sentiment\n"
            f"- {news_sentiment}\n\n"
            "## Live Market Data\n"
            f"{market_data}\n\n"
            "Based on all the information, what is your final decision?"
        )
        
        completion = client.chat.completions.create(
            model="google/gemini-flash-1.5", # Powerful and fast model
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
            max_tokens=10,
        )
        
        decision = completion.choices[0].message.content.strip().upper()
        if decision in ["LONG", "SHORT", "HOLD"]:
            return decision
        return "HOLD" # Fail-safe
    except Exception as e:
        print(f"Error with OpenRouter API: {e}")
        return "HOLD" # Fail-safe

def get_llm_consensus(market_data_str):
    """
    A full pipeline that gets news, filters it with Groq, and gets a final
    confirmation from OpenRouter.
    """
    print("Getting LLM consensus...")
    # 1. Get news from CryptoPanic
    news_titles = get_crypto_panic_news()
    
    # 2. Get sentiment from Groq
    news_sentiment = filter_news_with_groq(news_titles)
    print(f"Groq News Sentiment: {news_sentiment}")
    
    # 3. Get final decision from OpenRouter
    final_decision = get_final_confirmation(market_data_str, news_sentiment)
    print(f"OpenRouter Final Decision: {final_decision}")
    
    return final_decision

# Example Usage
if __name__ == '__main__':
    # This requires API keys in a .env file
    
    # Simulate some market data
    market_data_example = """
    - Symbol: BTC/USDT
    - Orderbook Imbalance: 0.15 (More buy pressure)
    - 15m ATR: 50.25
    - 1h ATR: 120.80
    - 4h ATR: 350.10
    - Current Price is near the top of the 4h candle.
    """
    
    decision = get_llm_consensus(market_data_example)
    
    print(f"\n--- Consensus Reached: {decision} ---")
