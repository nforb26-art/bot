import sqlite3

class PersistentVault:
    def __init__(self, db_path='sovereign_vault.db'):
        self.db_path = db_path
        self._create_table()

    def _create_table(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    asset TEXT NOT NULL,
                    type TEXT NOT NULL, -- 'LONG' or 'SHORT'
                    entry_price REAL NOT NULL,
                    exit_price REAL,
                    amount REAL NOT NULL,
                    profit_loss REAL,
                    tax_owed REAL DEFAULT 0.0,
                    withdrawal_reserve REAL DEFAULT 0.0
                )
            ''')
            conn.commit()

    def record_trade(self, asset, trade_type, entry_price, amount, exit_price=None, profit_loss=None):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO trades (asset, type, entry_price, amount, exit_price, profit_loss)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (asset, trade_type, entry_price, amount, exit_price, profit_loss))
            conn.commit()
            return cursor.lastrowid

    def update_trade_exit(self, trade_id, exit_price, profit_loss):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE trades
                SET exit_price = ?, profit_loss = ?
                WHERE id = ?
            ''', (exit_price, profit_loss, trade_id))
            conn.commit()

    def calculate_nigeria_tax(self, income_ngn):
        # 2026 NTA progressive bands
        if income_ngn <= 800000:
            return 0.0
        elif income_ngn <= 3000000:
            return (income_ngn - 800000) * 0.15
        else:
            return 220000 + (income_ngn - 3000000) * 0.18 # 220,000 is tax on 3,000,000 - 800,000 = 2,200,000 * 0.15

    def get_total_profit_loss(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT SUM(profit_loss) FROM trades WHERE profit_loss IS NOT NULL")
            total_profit_loss = cursor.fetchone()[0]
            return total_profit_loss if total_profit_loss is not None else 0.0

    def get_total_tax_owed(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT SUM(tax_owed) FROM trades")
            total_tax = cursor.fetchone()[0]
            return total_tax if total_tax is not None else 0.0

    def update_tax_owed(self, trade_id, tax_amount):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE trades
                SET tax_owed = ?
                WHERE id = ?
            ''', (tax_amount, trade_id))
            conn.commit()

    def add_to_withdrawal_reserve(self, trade_id, amount):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE trades
                SET withdrawal_reserve = withdrawal_reserve + ?
                WHERE id = ?
            ''', (amount, trade_id))
            conn.commit()

    def get_total_withdrawal_reserve(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT SUM(withdrawal_reserve) FROM trades")
            total_reserve = cursor.fetchone()[0]
            return total_reserve if total_reserve is not None else 0.0

    def get_live_pnl(self):
        # This would typically involve fetching current open trades and their real-time PnL.
        # For now, let's assume it returns the sum of closed profit/loss.
        return self.get_total_profit_loss()
