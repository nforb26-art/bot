
import ccxt.pro as ccxt
import pandas as pd
import asyncio
from ..config import config

class MarketScanner:
    def __init__(self):
        # Initialize exchange connections
        self.exchanges = {
            "binance": ccxt.binance({
                'apiKey': config.BINANCE_API_KEY,
                'secret': config.BINANCE_SECRET_KEY,
                'options': {'defaultType': 'future'},
            })
        }
        # Note: Deriv is not officially supported by CCXT's unified API in the same way.
        # It would require a custom implementation or a different library.
        # We will focus on Binance for now.

    async def close_connections(self):
        """Gracefully close all exchange connections."""
        for ex in self.exchanges.values():
            await ex.close()

    async def get_multi_timeframe_data(self, symbol, timeframes=['15m', '1h', '4h'], limit=100):
        """
        Fetches OHLCV data for multiple timeframes.
        """
        exchange = self.exchanges['binance']
        data = {}
        try:
            for tf in timeframes:
                ohlcv = await exchange.fetch_ohlcv(symbol, timeframe=tf, limit=limit)
                df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                df.set_index('timestamp', inplace=True)
                data[tf] = df
            return data
        except ccxt.Error as e:
            print(f"Error fetching multi-timeframe data for {symbol}: {e}")
            return None

    async def check_orderbook_imbalance(self, symbol, depth=20):
        """
        Calculates the order book imbalance.
        Returns a value between -1 and 1.
        > 0 means more buy pressure.
        < 0 means more sell pressure.
        """
        exchange = self.exchanges['binance']
        try:
            orderbook = await exchange.fetch_order_book(symbol, limit=depth)
            bids = orderbook['bids']
            asks = orderbook['asks']
            
            if not bids or not asks:
                return 0

            bid_volume = sum([bid[1] for bid in bids])
            ask_volume = sum([ask[1] for ask in asks])
            
            total_volume = bid_volume + ask_volume
            if total_volume == 0:
                return 0
            
            imbalance = (bid_volume - ask_volume) / total_volume
            return imbalance
        except ccxt.Error as e:
            print(f"Error fetching order book for {symbol}: {e}")
            return 0

    async def get_trading_signals(self, count=3):
        """
        Generates a list of trading signals.
        NOTE: This is a placeholder implementation.
        In a real-world scenario, this would involve complex logic
        analyzing market data.
        """
        # In a real implementation, you would scan multiple assets
        # and apply your trading logic.
        # For now, we return a mock list.
        print("Generating mock trading signals...")
        await asyncio.sleep(1) # Simulate network/computation time

        signals = [
            {"symbol": "BTC/USDT", "direction": "LONG", "reason": "Strong bullish momentum on 1H chart and high orderbook imbalance."},
            {"symbol": "ETH/USDT", "direction": "SHORT", "reason": "Bearish divergence on 4H RSI and breaking below 15m support."},
            {"symbol": "SOL/USDT", "direction": "LONG", "reason": "High volume breakout above recent resistance on 15m timeframe."},
        ]
        return signals[:count]

    @staticmethod
    def calculate_atr(df, period=14):
        """
        Calculates the Average True Range (ATR).
        """
        df['high-low'] = df['high'] - df['low']
        df['high-prev_close'] = abs(df['high'] - df['close'].shift(1))
        df['low-prev_close'] = abs(df['low'] - df['close'].shift(1))
        
        df['tr'] = df[['high-low', 'high-prev_close', 'low-prev_close']].max(axis=1)
        
        # Using EMA for ATR calculation is common
        atr = df['tr'].ewm(alpha=1/period, adjust=False).mean()
        return atr.iloc[-1]

async def main():
    """Example usage of the MarketScanner."""
    scanner = MarketScanner()
    symbol = 'BTC/USDT'
    
    print(f"--- Scanning {symbol} on Binance ---")
    
    # 1. Get Multi-Timeframe Data
    timeframe_data = await scanner.get_multi_timeframe_data(symbol)
    if timeframe_data:
        for tf, df in timeframe_data.items():
            print(f"\n--- Data for {tf} timeframe ---")
            print(df.tail(3))
            
            # 2. Calculate ATR for each timeframe
            atr = MarketScanner.calculate_atr(df)
            print(f"ATR ({tf}): {atr:.2f}")

    # 3. Check Orderbook Imbalance
    imbalance = await scanner.check_orderbook_imbalance(symbol)
    print(f"\nOrderbook Imbalance: {imbalance:.4f}")
    if imbalance > 0.1:
        print("Interpretation: Significant buy pressure.")
    elif imbalance < -0.1:
        print("Interpretation: Significant sell pressure.")
    else:
        print("Interpretation: Relatively balanced orderbook.")
        
    await scanner.close_connections()

if __name__ == '__main__':
    # This requires a .env file with BINANCE_API_KEY and BINANCE_SECRET_KEY
    # You might need to enable Futures trading on your API key.
    asyncio.run(main())
