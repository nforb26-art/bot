
from ..config import config
from .database import get_all_trades

# --- State Variables ---
# In a real application, these should be persisted in a database or a state file.
# For now, we'll keep them in memory.
daily_starting_equity = 10000  # Example: $10,000
current_equity = 10000
profit_reserve = 0

def get_profit_reserve():
    """Returns the current profit reserve."""
    return profit_reserve

def get_current_equity():
    """Returns the current equity."""
    return current_equity


def calculate_kelly_position_size(portfolio_balance, price, win_prob=0.55, win_loss_ratio=1.2):
    """
    Calculates position size using the Kelly Criterion.
    
    :param portfolio_balance: Total capital available for trading.
    :param price: The current price of the asset.
    :param win_prob: The estimated probability of a winning trade.
    :param win_loss_ratio: The ratio of the average win size to the average loss size.
    :return: The size of the position in asset units (e.g., number of BTC).
    """
    if win_loss_ratio == 0:
        return 0

    # Kelly formula: K = W - [(1 - W) / R]
    # W = Win Probability, R = Win/Loss Ratio
    kelly_percentage = win_prob - ((1 - win_prob) / win_loss_ratio)
    
    if kelly_percentage <= 0:
        return 0 # Do not trade if the edge is not positive
        
    # Apply a fractional Kelly to be less aggressive
    fractional_kelly = kelly_percentage * config.KELLY_FRACTION
    
    # Calculate the dollar amount to risk
    capital_to_risk = portfolio_balance * fractional_kelly
    
    # Convert to position size in asset units
    position_size = capital_to_risk / price
    
    return position_size


def calculate_atr_stop_loss(entry_price, atr, direction, multiplier=1.5):
    """
    Calculates the stop-loss price based on ATR.
    
    :param entry_price: The price at which the trade was entered.
    :param atr: The Average True Range value for the trade's timeframe.
    :param direction: 'LONG' or 'SHORT'.
    :param multiplier: The factor to multiply the ATR by.
    :return: The calculated stop-loss price.
    """
    atr_offset = atr * multiplier
    
    if direction.upper() == 'LONG':
        stop_loss_price = entry_price - atr_offset
    elif direction.upper() == 'SHORT':
        stop_loss_price = entry_price + atr_offset
    else:
        raise ValueError("Direction must be 'LONG' or 'SHORT'")
        
    return stop_loss_price


def update_profit_reserve(pnl_usd):
    """
    Adds a percentage of winnings to the profit reserve.
    This should be called after a trade is closed.
    """
    global profit_reserve, current_equity
    
    # Update equity with the PnL from the closed trade
    current_equity += pnl_usd
    
    if pnl_usd > 0:
        reserved_amount = pnl_usd * config.PROFIT_RESERVE_PERCENTAGE
        profit_reserve += reserved_amount


def check_kill_switch():
    """
    Checks if the daily equity has dropped below the maximum drawdown limit.
    
    :return: True if the kill switch should be activated, False otherwise.
    """
    global daily_starting_equity, current_equity
    
    drawdown = (current_equity - daily_starting_equity) / daily_starting_equity
    
    if drawdown < config.MAX_DAILY_DRAWDOWN:
        print(f"!!! KILL SWITCH ACTIVATED !!!")
        print(f"Daily Drawdown: {drawdown:.2%}")
        print(f"Starting Equity: ${daily_starting_equity:.2f}, Current Equity: ${current_equity:.2f}")
        return True
    return False

def reset_daily_equity():
    """Resets the daily starting equity. To be called once per day."""
    global daily_starting_equity, current_equity
    daily_starting_equity = current_equity
    print(f"Daily equity reset. New starting equity: ${daily_starting_equity:.2f}")

# Example Usage
if __name__ == '__main__':
    print("--- Risk Management Examples ---")
    
    # 1. Kelly Criterion
    portfolio_value = 10000
    asset_price = 50000
    size = calculate_kelly_position_size(portfolio_value, asset_price)
    print(f"Portfolio: ${portfolio_value}, Asset Price: ${asset_price}")
    print(f"Suggested Position Size (BTC): {size:.6f}")
    print(f"In Dollars: ${size * asset_price:.2f}")

    print("\n" + "-"*20 + "\n")
    
    # 2. ATR Stop-Loss
    long_entry = 50000
    short_entry = 52000
    atr_val = 800
    
    long_sl = calculate_atr_stop_loss(long_entry, atr_val, 'LONG')
    short_sl = calculate_atr_stop_loss(short_entry, atr_val, 'SHORT')
    print(f"Long entry at ${long_entry} with ATR {atr_val} -> SL @ ${long_sl:.2f}")
    print(f"Short entry at ${short_entry} with ATR {atr_val} -> SL @ ${short_sl:.2f}")
    
    print("\n" + "-"*20 + "\n")

    # 3. Profit Reserve & Equity Update
    print(f"Initial Equity: ${current_equity}, Initial Reserve: ${profit_reserve}")
    # Simulate a winning trade of $500
    update_profit_reserve(500)
    print(f"After +$500 win -> Equity: ${current_equity:.2f}, Reserve: ${profit_reserve:.2f}")
    # Simulate a losing trade of $200
    update_profit_reserve(-200)
    print(f"After -$200 loss -> Equity: ${current_equity:.2f}, Reserve: ${profit_reserve:.2f}")

    print("\n" + "-"*20 + "\n")

    # 4. Kill-Switch Check
    print(f"Current Equity for kill switch check: ${current_equity:.2f}")
    is_killed = check_kill_switch()
    print(f"Kill Switch Activated: {is_killed}")
    
    # Simulate a large loss
    current_equity -= 600
    print(f"\nAfter another $600 loss, equity is ${current_equity:.2f}")
    is_killed = check_kill_switch()
    print(f"Kill Switch Activated: {is_killed}")
