import asyncio
import os
from functools import wraps
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)
from dotenv import find_dotenv, set_key
import threading

from ..config import config
from .database import get_all_trades, get_open_positions
from .tax_engine import get_total_tax_report
from .risk_management import get_current_equity, get_profit_reserve

# --- Decorator for Whitelisting ---
def whitelisted_only(func):
    """Decorator to restrict access to whitelisted Telegram user IDs."""

    @wraps(func)
    async def wrapped(
        update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs
    ):
        user_id = update.effective_user.id
        if user_id != config.WHITELISTED_TELEGRAM_ID:
            await update.message.reply_text("⛔ You are not authorized to use this bot.")
            print(f"Unauthorized access attempt by user ID: {user_id}")
            return
        return await func(update, context, *args, **kwargs)

    return wrapped


# --- API Update Conversation ---
CHOOSING_API, TYPING_API_KEY = range(2)

API_KEY_OPTIONS = [
    "EXCHANGE_RATE_API_KEY",
    "CRYPTOPANIC_API_KEY",
    "GROQ_API_KEY",
    "OPENROUTER_API_KEY",
    "BYBIT_API_KEY",
    "BYBIT_SECRET_KEY",
]

@whitelisted_only
async def api_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Start the conversation to update an API key."""
    reply_keyboard = [API_KEY_OPTIONS[i:i + 2] for i in range(0, len(API_KEY_OPTIONS), 2)]
    reply_keyboard.append(["Done"])

    await update.message.reply_text(
        "Please choose the API key you want to update. "
        "The bot may need to be restarted to apply the changes.",
        reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True),
    )
    return CHOOSING_API


async def received_api_choice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Ask for the new API key value."""
    text = update.message.text
    if text not in API_KEY_OPTIONS:
        await update.message.reply_text(
            "Invalid selection. Please choose one of the available options.",
            reply_markup=ReplyKeyboardMarkup(
                [API_KEY_OPTIONS[i:i + 2] for i in range(0, len(API_KEY_OPTIONS), 2)] + [["Done"]],
                one_time_keyboard=True
            ),
        )
        return CHOOSING_API

    context.user_data["api_key_to_update"] = text
    await update.message.reply_text(
        f"Please send me the new value for {text}.",
        reply_markup=ReplyKeyboardRemove(),
    )
    return TYPING_API_KEY


async def received_api_key(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Update the .env file and end the conversation."""
    new_api_key = update.message.text
    api_key_to_update = context.user_data["api_key_to_update"]

    try:
        env_file = find_dotenv()
        if not env_file:
            env_file = ".env" # Create if it doesn't exist
        
        set_key(env_file, api_key_to_update, new_api_key)
        
        # Update the config object in memory
        setattr(config, api_key_to_update, new_api_key)

        await update.message.reply_text(
            f"✅ {api_key_to_update} has been updated. "
            "Please restart the bot for the changes to take full effect.",
            reply_markup=ReplyKeyboardRemove(),
        )
    except Exception as e:
        await update.message.reply_text(
            f"An error occurred while updating the API key: {e}",
            reply_markup=ReplyKeyboardRemove(),
        )
        print(f"Error updating .env file: {e}")

    del context.user_data["api_key_to_update"]
    return ConversationHandler.END


async def done_api(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancel the API update conversation."""
    if "api_key_to_update" in context.user_data:
        del context.user_data["api_key_to_update"]
    await update.message.reply_text(
        "API key update process canceled.",
        reply_markup=ReplyKeyboardRemove(),
    )
    return ConversationHandler.END


# --- Command Handlers ---
@whitelisted_only
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /start command."""
    await update.message.reply_text(
        "Sovereign Bot Activated. I am ready to trade.\n"
        "Use /help to see available commands."
    )


@whitelisted_only
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /help command."""
    help_text = (
        "Available Commands:\n"
        "/status - Show live PnL and open positions.\n"
        "/tax - Display the NTA 2026 tax report.\n"
        "/reserve - Show the current saved profit reserve.\n"
        "/signal - Get the latest trading signals.\n"
        "/history - Show all executed trades.\n"
        "/pause - Pause the trading loop.\n"
        "/resume - Resume the trading loop.\n"
        "/api - Update API keys.\n"
        "/kill - Emergency stop to close all positions.\n"
        "/restart - Restart the bot.\n"
    )
    await update.message.reply_text(help_text)


@whitelisted_only
async def signal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /signal command, fetching trading signals."""
    scanner = context.bot_data.get("scanner")
    if not scanner:
        await update.message.reply_text(
            "The market scanner is not available yet. Please wait a moment and try again."
        )
        return

    await update.message.reply_text("🔍 Scanning for trading signals...")

    try:
        signals = await scanner.get_trading_signals(count=3)
        if not signals:
            await update.message.reply_text(
                "No significant trading signals found at the moment."
            )
            return

        response = "--- Trading Signals ---\n\n"
        for i, sig in enumerate(signals, 1):
            response += (
                f"SIGNAL {i}:\n"
                f"  Asset: {sig['symbol']}\n"
                f"  Direction: {sig['direction']}\n"
                f"  Reason: {sig['reason']}\n\n"
            )

        await update.message.reply_text(f"<pre>{response}</pre>", parse_mode="HTML")

    except Exception as e:
        print(f"Error getting trading signals: {e}")
        await update.message.reply_text(
            "An error occurred while fetching signals. The engineering team has been notified."
        )


@whitelisted_only
async def tax_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /tax command, returning the tax report."""
    report = get_total_tax_report()
    await update.message.reply_text(f"<pre>{report}</pre>", parse_mode="HTML")


@whitelisted_only
async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /status command."""
    equity = get_current_equity()
    open_positions = get_open_positions()

    status_text = f"Current Equity: ${equity:,.2f}\n\n"

    if not open_positions:
        status_text += "No open positions."
    else:
        status_text += "--- Open Positions ---\n"
        for pos in open_positions:
            status_text += (
                f"#{pos['id']}: {pos['direction']} {pos['size']} {pos['asset']} "
                f"@ ${pos['entry_price']:,.2f}\n"
            )

    await update.message.reply_text(f"<pre>{status_text}</pre>", parse_mode="HTML")


@whitelisted_only
async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /history command."""
    trades = get_all_trades()
    if not trades:
        await update.message.reply_text("No trade history found.")
        return

    history_text = "--- Trade History ---\n\n"
    for trade in trades:
        trade_time = datetime.fromisoformat(trade["timestamp"]).strftime(
            "%Y-%m-%d %H:%M"
        )
        pnl_str = f"${trade['pnl_usd']:,.2f}" if trade["pnl_usd"] is not None else "N/A"
        status = trade["status"]
        trade_char = (
            "✅" if trade["is_win"] else "❌" if trade["is_win"] is not None else "🔵"
        )

        history_text += (
            f"{trade_char} [{trade_time}] {trade['direction']} {trade['asset']}\n"
            f"   Entry: ${trade['entry_price']:,.2f}, Exit: ${trade['exit_price']:,.2f}\n"
            f"   Size: {trade['size']}, PnL: {pnl_str}, Status: {status}\n\n"
        )

    await update.message.reply_text(f"<pre>{history_text}</pre>", parse_mode="HTML")


@whitelisted_only
async def reserve_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /reserve command."""
    reserve = get_profit_reserve()
    await update.message.reply_text(f"💰 Profit Reserve: ${reserve:,.2f}")


@whitelisted_only
async def kill_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /kill command, engaging the emergency stop."""
    executor = context.bot_data.get("executor")
    if executor:
        await update.message.reply_text(
            "🚨 ENGAGING EMERGENCY KILL SWITCH! 🚨\nClosing all positions..."
        )
        # Running in a separate thread to avoid blocking the bot
        threading.Thread(target=executor.emergency_kill_switch).start()
        await update.message.reply_text("All positions are being closed.")
    else:
        await update.message.reply_text(
            "Executor not available. Cannot engage kill switch."
        )


@whitelisted_only
async def pause_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /pause command, pausing the trading loop."""
    event = context.bot_data.get("trading_active_event")
    if event and event.is_set():
        event.clear()
        await update.message.reply_text("⏸️ Trading loop paused.")
    elif event:
        await update.message.reply_text("Trading loop is already paused.")
    else:
        await update.message.reply_text("Trading event not available.")


@whitelisted_only
async def resume_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /resume command, resuming the trading loop."""
    event = context.bot_data.get("trading_active_event")
    if event and not event.is_set():
        event.set()
        await update.message.reply_text("▶️ Trading loop resumed.")
    elif event:
        await update.message.reply_text("Trading loop is already active.")
    else:
        await update.message.reply_text("Trading event not available.")


@whitelisted_only
async def restart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /restart command, which restarts the bot."""
    await update.message.reply_text("🔄 Restarting the bot...")
    await asyncio.sleep(1) # Give time for the message to be sent
    os._exit(1) # Force exit, relying on an external process manager to restart


def setup_bot(shared_context):
    """Sets up and returns the Telegram bot application."""
    if (
        not config.TELEGRAM_BOT_TOKEN
        or config.TELEGRAM_BOT_TOKEN == "YOUR_TELEGRAM_BOT_TOKEN"
    ):
        raise ValueError(
            "Telegram Bot Token is not configured. Please set it in your .env file."
        )
    if not config.WHITELISTED_TELEGRAM_ID or config.WHITELISTED_TELEGRAM_ID == 0:
        raise ValueError(
            "Whitelisted Telegram ID is not configured. Please set it in your .env file."
        )

    application = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()

    # Pass the shared context to the bot
    application.bot_data["executor"] = shared_context.get("executor")
    application.bot_data["scanner"] = shared_context.get("scanner")
    application.bot_data["trading_active_event"] = shared_context.get(
        "trading_active_event"
    )

    # --- Conversation Handler for API Updates ---
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("api", api_command)],
        states={
            CHOOSING_API: [
                MessageHandler(
                    filters.TEXT & ~filters.COMMAND & filters.Regex(f'^({"|".join(API_KEY_OPTIONS)})$'),
                    received_api_choice,
                )
            ],
            TYPING_API_KEY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, received_api_key)
            ],
        },
        fallbacks=[MessageHandler(filters.Regex("^Done$"), done_api)],
    )

    application.add_handler(conv_handler)

    # Register handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("tax", tax_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("reserve", reserve_command))
    application.add_handler(CommandHandler("signal", signal_command))
    application.add_handler(CommandHandler("history", history_command))
    application.add_handler(CommandHandler("kill", kill_command))
    application.add_handler(CommandHandler("pause", pause_command))
    application.add_handler(CommandHandler("resume", resume_command))
    application.add_handler(CommandHandler("restart", restart_command))

    return application


async def run_bot(shared_context):
    """Runs the bot."""
    print("Starting Telegram bot...")
    app = setup_bot(shared_context)
    await app.run_polling()
