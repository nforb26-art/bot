
import requests
import os
from .database import get_all_trades

# It's better to store API keys in environment variables or a config file
# For simplicity here, but should be changed for production
EXCHANGE_RATE_API_KEY = os.environ.get("EXCHANGE_RATE_API_KEY", "d5952f7a5c0b16a70c534f37") # Replace with your actual key if needed
USD_NGN_API_URL = f"https://v6.exchangerate-api.com/v6/{EXCHANGE_RATE_API_KEY}/latest/USD"

def get_usd_ngn_rate():
    """Fetches the latest USD to NGN exchange rate."""
    try:
        response = requests.get(USD_NGN_API_URL)
        response.raise_for_status()
        data = response.json()
        if data and data.get("result") == "success":
            return data["conversion_rates"].get("NGN")
    except requests.exceptions.RequestException as e:
        print(f"Error fetching exchange rate: {e}")
        return None # Return a default or handle the error appropriately
    return 1500.0 # Fallback rate

def calculate_nta_2026_tax(total_profit_ngn):
    """
    Calculates the tax on a given profit in NGN based on 2026 NTA progressive bands.
    """
    tax = 0.0
    
    # Band 1: ₦0 - ₦800,000 @ 0%
    # No tax in this band
    
    # Band 2: ₦800,001 - ₦3,000,000 @ 15%
    if total_profit_ngn > 800000:
        taxable_at_15 = min(total_profit_ngn - 800000, 3000000 - 800000)
        tax += taxable_at_15 * 0.15
        
    # Band 3: ₦3,000,001 - ₦12,000,000 @ 18%
    if total_profit_ngn > 3000000:
        # As per the prompt, the top band is 12M. It is assumed profits above 12M are also taxed at 18%.
        taxable_at_18 = total_profit_ngn - 3000000
        tax += taxable_at_18 * 0.18

    return tax

def get_total_tax_report():
    """
    Calculates the total profit from winning trades and the corresponding tax owed.
    """
    all_trades = get_all_trades()
    total_profit_usd = sum(trade['pnl_usd'] for trade in all_trades if trade['pnl_usd'] and trade['pnl_usd'] > 0)
    
    usd_ngn_rate = get_usd_ngn_rate()
    if usd_ngn_rate is None:
        return "Could not retrieve USD/NGN exchange rate. Cannot calculate tax."

    total_profit_ngn = total_profit_usd * usd_ngn_rate
    tax_owed_ngn = calculate_nta_2026_tax(total_profit_ngn)
    
    report = (
        f"NTA 2026 Tax Report\n"
        f"---------------------\n"
        f"Live Rate: 1 USD = {usd_ngn_rate:.2f} NGN\n"
        f"Total Realized Profit: ${total_profit_usd:.2f} USD\n"
        f"Total Realized Profit: ₦{total_profit_ngn:,.2f} NGN\n"
        f"Total Tax Owed: ₦{tax_owed_ngn:,.2f} NGN\n"
    )
    return report

if __name__ == '__main__':
    # Example usage:
    # To run this directly, you need to ensure the database has some trades.
    # We will simulate some profit for demonstration.
    
    print("--- Simulating Tax Calculation ---")
    
    # Create dummy DB for testing if it doesn't exist
    from .database import create_db, log_trade, close_trade
    db_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'sovereign_vault.db')
    if not os.path.exists(db_path):
        print("Creating dummy database and trades...")
        create_db()
        # Simulate a few winning trades
        trade1 = log_trade("BTC/USDT", "LONG", 60000, 0.1)
        close_trade(trade1, 65000) # +$500 profit
        trade2 = log_trade("ETH/USDT", "LONG", 3000, 1)
        close_trade(trade2, 3500) # +$500 profit
        
        # Simulate one losing trade (should be ignored by tax calculation)
        trade3 = log_trade("ADA/USDT", "LONG", 1.5, 1000)
        close_trade(trade3, 1.4) # -$100 loss

    print(get_total_tax_report())
    
