
import ccxt
from ..config import config
from . import database as db
from . import risk_management as rm

class TradeExecutor:
    def __init__(self):
        self.exchange = None
        
        # --- Attempt to initialize exchanges based on available keys ---
        
        # 1. Try Bybit
        if config.BYBIT_API_KEY and config.BYBIT_SECRET_KEY:
            try:
                self.exchange = ccxt.bybit({
                    'apiKey': config.BYBIT_API_KEY,
                    'secret': config.BYBIT_SECRET_KEY,
                    'options': {'defaultType': 'future'},
                })
                print("TradeExecutor initialized for Bybit Futures.")
                return # Successfully initialized
            except Exception as e:
                print(f"Bybit initialization failed: {e}")
                self.exchange = None # Ensure exchange is None if init fails

        # 2. Try Binance (if Bybit failed)
        if not self.exchange and config.BINANCE_API_KEY and config.BINANCE_SECRET_KEY:
            try:
                self.exchange = ccxt.binance({
                    'apiKey': config.BINANCE_API_KEY,
                    'secret': config.BINANCE_SECRET_KEY,
                    'options': {'defaultType': 'future'},
                })
                print("TradeExecutor initialized for Binance Futures.")
                return # Successfully initialized
            except Exception as e:
                print(f"Binance initialization failed: {e}")
                self.exchange = None

        # 3. If no exchange was initialized
        if not self.exchange:
            print("No valid exchange configuration found. TradeExecutor is not operational.")


    def open_position(self, symbol, direction, size, stop_loss_price):
        """
        Opens a new position.
        
        :param symbol: e.g., 'BTC/USDT'
        :param direction: 'LONG' or 'SHORT'
        :param size: The amount of the asset to trade.
        :param stop_loss_price: The calculated stop-loss price.
        :return: The trade ID from the database or None on failure.
        """
        if not self.exchange:
            print("Cannot open position, exchange not initialized.")
            return None
            
        try:
            print(f"Attempting to open {direction} position for {size} {symbol}...")
            
            # CCXT uses 'buy' for LONG and 'sell' for SHORT
            side = 'buy' if direction.upper() == 'LONG' else 'sell'
            
            # Create a market order
            order = self.exchange.create_market_order(symbol, side, size)
            
            print("--- Order Executed ---")
            print(order)
            
            # Log the trade to our internal database
            entry_price = order['price']
            trade_id = db.log_trade(
                asset=symbol,
                direction=direction,
                entry_price=entry_price,
                size=size,
                status="OPEN"
            )
            
            # Now, create a stop-loss order on the exchange
            sl_params = {'stopPrice': stop_loss_price}
            sl_side = 'sell' if direction.upper() == 'LONG' else 'buy'
            stop_loss_order = self.exchange.create_order(symbol, 'STOP_MARKET', sl_side, size, params=sl_params)
            
            print("--- Stop-Loss Order Placed ---")
            print(stop_loss_order)
            
            return trade_id

        except ccxt.Error as e:
            print(f"Error opening position: {e}")
            return None

    def close_position(self, trade_id, reason="Manual Closure"):
        """
        Closes an open position by its trade ID from our database.
        """
        if not self.exchange:
            print("Cannot close position, exchange not initialized.")
            return
            
        with db.sqlite3.connect(db.DB_FILE) as conn:
            conn.row_factory = db.sqlite3.Row
            trade = conn.execute("SELECT * FROM trades WHERE id = ? AND status = 'OPEN'", (trade_id,)).fetchone()

        if not trade:
            print(f"No open trade found with ID {trade_id}")
            return

        symbol = trade['asset']
        direction = trade['direction']
        size = trade['size']
        
        try:
            print(f"Attempting to close position {trade_id} ({direction} {size} {symbol}) due to: {reason}")
            
            # The side to close is the opposite of the opening side
            side = 'sell' if direction.upper() == 'LONG' else 'buy'
            
            # First, cancel any open stop-loss orders for this position.
            # This is a simplification; a real system needs to track order IDs.
            self.exchange.cancel_all_orders(symbol)
            
            # Close with a market order
            order = self.exchange.create_market_order(symbol, side, size)
            
            print("--- Closing Order Executed ---")
            print(order)
            
            # Update our database
            exit_price = order['price']
            pnl_usd = db.close_trade(trade_id, exit_price)
            
            if pnl_usd is not None:
                print(f"Position {trade_id} closed. PnL: ${pnl_usd:.2f}")
                # Update profit reserve and equity
                rm.update_profit_reserve(pnl_usd)
            
        except ccxt.Error as e:
            print(f"Error closing position {trade_id}: {e}")

    def emergency_kill_switch(self):
        """Closes all open positions."""
        print("!!! EMERGENCY KILL SWITCH ENGAGED !!!")
        open_positions = db.get_open_positions()
        if not open_positions:
            print("No open positions to close.")
            return
            
        for pos in open_positions:
            self.close_position(pos['id'], reason="EMERGENCY KILL SWITCH")
            
# --- Example Usage ---
# NOTE: Running this file will execute real trades if your API keys are valid.
# Use with extreme caution. It's best to use a testnet account.
if __name__ == '__main__':
    
    # This example is commented out to prevent accidental execution.
    
    # async def run_example():
    #     executor = TradeExecutor()
    #     if not executor.exchange:
    #         return
    #     
    #     # Ensure database is clean for example
    #     db.create_db()
    # 
    #     # --- Example 1: Open and Close a Long Position ---
    #     symbol = 'BTC/USDT'
    #     price = await executor.exchange.fetch_ticker(symbol)['last']
    #     atr = 100 # Dummy ATR
    #     
    #     # Calculate size and SL
    #     position_size = 0.001 # Fixed small size for safety
    #     stop_loss = rm.calculate_atr_stop_loss(price, atr, 'LONG')
    # 
    #     # Open
    #     trade_id = executor.open_position(symbol, 'LONG', position_size, stop_loss)
    #     
    #     if trade_id:
    #         print(f"Opened trade with ID: {trade_id}")
    #         # Wait a bit before closing
    #         await asyncio.sleep(10)
    #         # Close
    #         executor.close_position(trade_id, reason="Example closure")

    # asyncio.run(run_example())
    
    print("Execution module loaded. Examples are commented out for safety.")
    print("Do not run this file directly unless you are on a testnet and understand the risks.")

