
import sqlite3
from datetime import datetime
import os

DB_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'sovereign_vault.db')

def create_db():
    """Initializes the database and creates the trades table if it doesn't exist."""
    # Ensure the data directory exists
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                asset TEXT NOT NULL,
                direction TEXT NOT NULL,
                entry_price REAL NOT NULL,
                exit_price REAL,
                size REAL NOT NULL,
                pnl_usd REAL,
                is_win BOOLEAN,
                status TEXT NOT NULL
            )
        """)
        conn.commit()

def log_trade(asset, direction, entry_price, size, status="OPEN"):
    """Logs a new trade or updates an existing one."""
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        timestamp = datetime.utcnow().isoformat()
        cursor.execute("""
            INSERT INTO trades (timestamp, asset, direction, entry_price, size, status)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (timestamp, asset, direction, entry_price, size, status))
        conn.commit()
        return cursor.lastrowid

def close_trade(trade_id, exit_price):
    """Updates a trade to mark it as closed."""
    with sqlite3.connect(DB_FILE) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get the original trade details
        cursor.execute("SELECT * FROM trades WHERE id = ?", (trade_id,))
        trade = cursor.fetchone()
        
        if not trade:
            return None

        entry_price = trade['entry_price']
        size = trade['size']
        direction = trade['direction']
        
        # Calculate PnL
        if direction.upper() == 'LONG':
            pnl_usd = (exit_price - entry_price) * size
        else: # SHORT
            pnl_usd = (entry_price - exit_price) * size
            
        is_win = pnl_usd > 0
        
        cursor.execute("""
            UPDATE trades
            SET exit_price = ?, pnl_usd = ?, is_win = ?, status = 'CLOSED'
            WHERE id = ?
        """, (exit_price, pnl_usd, is_win, trade_id))
        
        conn.commit()
        return pnl_usd

def get_all_trades():
    """Retrieves all trades from the database."""
    with sqlite3.connect(DB_FILE) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM trades ORDER BY timestamp DESC")
        return cursor.fetchall()

def get_open_positions():
    """Retrieves all open positions from the database."""
    with sqlite3.connect(DB_FILE) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM trades WHERE status = 'OPEN' ORDER BY timestamp ASC")
        return cursor.fetchall()

if __name__ == '__main__':
    # Example usage:
    print("Initializing database...")
    create_db()
    print("Database initialized.")

    # Log a new trade
    #trade_id = log_trade(asset="BTC/USDT", direction="LONG", entry_price=50000, size=0.1)
    #print(f"Logged new trade with ID: {trade_id}")

    # Close the trade
    #pnl = close_trade(trade_id, 52000)
    #print(f"Closed trade. PnL: ${pnl:.2f}")

    # Log a short trade
    #trade_id_short = log_trade(asset="ETH/USDT", direction="SHORT", entry_price=4000, size=2)
    #print(f"Logged new short trade with ID: {trade_id_short}")

    # Close the short trade
    #pnl_short = close_trade(trade_id_short, 3900)
    #print(f"Closed short trade. PnL: ${pnl_short:.2f}")


    #print("\\n--- All Trades ---")
    #all_trades = get_all_trades()
    #for trade in all_trades:
    #    print(dict(trade))
        
