


import asyncio

import threading

import time

from flask import Flask, jsonify



# --- Module Imports ---

from sovereign_bot.config import config

from sovereign_bot.core.database import create_db

from sovereign_bot.core.market_scanner import MarketScanner

from sovereign_bot.core.llm_consensus import get_llm_consensus

from sovereign_bot.core.risk_management import (

    calculate_kelly_position_size,

    calculate_atr_stop_loss,

    check_kill_switch,

    reset_daily_equity,

    get_current_equity

)

from sovereign_bot.core.execution import TradeExecutor

import sovereign_bot.core.telegram_bot as telegram_bot



# --- Flask App for Uptime Robot ---

app = Flask(__name__)

@app.route('/')

def heartbeat():

    return jsonify({"status": "ok", "message": "Sovereign Bot is alive."})



def run_flask_app():

    # Running Flask in a separate thread

    app.run(host='0.0.0.0', port=config.FLASK_PORT)



# --- Core Trading Logic (Async) ---

async def trading_loop(shared_context):

    """The main autonomous trading loop, now asynchronous."""

    print("--- ASYNC TRADING LOOP ACTIVATED ---")

    

    # Initialization

    scanner = MarketScanner()

    executor = TradeExecutor()

    shared_context['executor'] = executor

    shared_context['scanner'] = scanner

    

    symbols_to_scan = ['BTC/USDT', 'ETH/USDT']

    loop_interval_seconds = 60 * 15

    last_reset_day = -1



    while True:

        if not shared_context['trading_active_event'].is_set():

            print("--- TRADING LOOP PAUSED ---")

            # Use an async-friendly wait

            while not shared_context['trading_active_event'].is_set():

                await asyncio.sleep(1)

        

        try:

            current_day = time.gmtime().tm_yday

            if current_day != last_reset_day:

                # This is a synchronous function

                await asyncio.to_thread(reset_daily_equity)

                last_reset_day = current_day

                print("Daily equity reset.")



            if await asyncio.to_thread(check_kill_switch):

                await asyncio.to_thread(executor.emergency_kill_switch)

                print("Trading loop paused for 24 hours due to kill switch.")

                await asyncio.sleep(60 * 60 * 24)

                continue



            print(f"\n--- New Trading Cycle ({time.ctime()}) ---")

            for symbol in symbols_to_scan:

                print(f"Scanning {symbol}...")

                

                # Await the async functions directly

                timeframe_data = await scanner.get_multi_timeframe_data(symbol)

                if not timeframe_data: continue

                

                imbalance = await scanner.check_orderbook_imbalance(symbol)

                # This is a synchronous function

                atr_1h = scanner.calculate_atr(timeframe_data['1h'])

                

                market_data_str = (

                    f"- Symbol: {symbol}\n"

                    f"- Orderbook Imbalance: {imbalance:.4f}\n"

                    f"- 1h ATR: {atr_1h:.2f}\n"

                    f"- Current Price: {timeframe_data['1h']['close'].iloc[-1]}\n"

                )

                

                # Run the blocking LLM call in a separate thread

                decision = await asyncio.to_thread(get_llm_consensus, market_data_str)



                if decision in ["LONG", "SHORT"]:

                    print(f"Decision for {symbol}: {decision}. Preparing to execute...")

                    current_price = timeframe_data['1h']['close'].iloc[-1]

                    # Run sync functions in a thread

                    equity = await asyncio.to_thread(get_current_equity)

                    position_size = await asyncio.to_thread(calculate_kelly_position_size, equity, current_price)

                    

                    if position_size <= 0:

                        print("Position size is zero. Skipping trade.")

                        continue

                        

                    stop_loss = await asyncio.to_thread(calculate_atr_stop_loss, current_price, atr_1h, decision)

                    # Run the blocking execution call in a separate thread

                    await asyncio.to_thread(executor.open_position, symbol, decision, position_size, stop_loss)

                else:

                    print(f"Decision for {symbol}: HOLD")



            print(f"--- Cycle Complete. Sleeping for {loop_interval_seconds / 60} minutes. ---")

            await asyncio.sleep(loop_interval_seconds)



        except Exception as e:

            print(f"An error occurred in the trading loop: {e}")

            await asyncio.sleep(60)



# --- Main Application Entry Point ---

async def main():

    """Main async function to start all components of the bot."""

    print("--- Starting Sovereign Bot ---")



    create_db()

    print("Database is ready.")

    

    # Shared context for inter-thread communication

    trading_active_event = threading.Event()

    trading_active_event.set() # Start in the active state

    shared_context = {

        'executor': None,

        'scanner': None,

        'trading_active_event': trading_active_event,

    }



    # Run Flask app in a separate thread

    flask_thread = threading.Thread(target=run_flask_app, daemon=True)

    flask_thread.start()

        

    # Create and run async tasks

    trading_task = asyncio.create_task(trading_loop(shared_context))

    telegram_task = asyncio.create_task(telegram_bot.run_bot(shared_context))

    

    # Wait for tasks to complete (which they won't, they loop forever)

    await asyncio.gather(trading_task, telegram_task)





if __name__ == '__main__':

    try:

        asyncio.run(main())

    except ValueError as e:

        print(f"ERROR: {e}\nBot cannot start. Check .env file.")

    except (KeyboardInterrupt, SystemExit):

        print("\nBot shutting down.")

    finally:

        print("Shutdown complete.")
