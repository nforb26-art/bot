
import os
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

class Config:
    # --- Telegram ---
    TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "YOUR_TELEGRAM_BOT_TOKEN")
    # Get your Telegram ID from a bot like @userinfobot
    WHITELISTED_TELEGRAM_ID = int(os.environ.get("WHITELISTED_TELEGRAM_ID", 0))

    # --- APIs ---
    # Exchange rate API (https://www.exchangerate-api.com)
    EXCHANGE_RATE_API_KEY = os.environ.get("EXCHANGE_RATE_API_KEY", "d5952f7a5c0b16a70c534f37")
    # CryptoPanic API (https://cryptopanic.com/developers/api/)
    CRYPTOPANIC_API_KEY = os.environ.get("CRYPTOPANIC_API_KEY", "YOUR_CRYPTOPANIC_API_KEY")
    # Groq API (https://console.groq.com/keys)
    GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "YOUR_GROQ_API_KEY")
    # OpenRouter API (https://openrouter.ai/keys)
    OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "YOUR_OPENROUTER_API_KEY")
    
    # --- Exchanges (use environment variables for security) ---
    BINANCE_API_KEY = os.environ.get("BINANCE_API_KEY")
    BINANCE_SECRET_KEY = os.environ.get("BINANCE_SECRET_KEY")
    BYBIT_API_KEY = os.environ.get("BYBIT_API_KEY")
    BYBIT_SECRET_KEY = os.environ.get("BYBIT_SECRET_KEY")
    # Add other exchange keys as needed (e.g., Deriv)

    # --- Risk Management ---
    KELLY_FRACTION = 0.1 # Example: Bet 10% of the portfolio
    MAX_DAILY_DRAWDOWN = -0.05 # 5%
    PROFIT_RESERVE_PERCENTAGE = 0.20 # 20%
    
    # --- Server ---
    FLASK_PORT = 8080

config = Config()
